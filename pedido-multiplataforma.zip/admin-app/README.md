# Admin App (Electron + React)

Este directorio contiene la app para PC Windows (modo cajero/administrador).

- `npm install` para instalar dependencias
- `npm run dist` para crear instalador Windows
- Usa `start_all.bat` para iniciar backend y app juntos
